95 KG Journey v3

Open index.html through an HTTPS host, then on iPhone Safari:
Share -> Add to Home Screen.

Features:
- 116 -> 95 kg progress
- weekly target
- 110/105/100/95 milestones
- streak
- daily habits
- workout reminder instructions
- 7-day consistency
- weight graph
- local device storage
